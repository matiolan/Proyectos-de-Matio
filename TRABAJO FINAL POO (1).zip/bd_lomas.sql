-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-07-2023 a las 05:38:02
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `bd_lomas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_cliente`
--

CREATE TABLE `tbl_cliente` (
  `idCliente` int(11) NOT NULL,
  `tipo` varchar(50) NOT NULL,
  `nombre` varchar(60) NOT NULL,
  `celular` int(50) NOT NULL,
  `direccion` varchar(80) NOT NULL,
  `doc` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_cliente`
--

INSERT INTO `tbl_cliente` (`idCliente`, `tipo`, `nombre`, `celular`, `direccion`, `doc`) VALUES
(1, 'Persona', 'Luis Untiveros', 999111222, 'Av la fontana. Usil', 75608712),
(2, 'Persona', 'Marko Villaizan', 999123321, 'Centro de Lima', 0),
(4, 'Persona', 'jude Bellingham', 999555111, 'España Madrid', 0),
(5, 'Persona', 'Luis Figo', 912345678, 'Estadio Portugal Azteca', 78904556),
(8, 'Empresa', 'Tambo', 1028372817, 'Calle Toulon - La molina', 2060789),
(9, 'Empresa', 'claro', 999666111, 'san isidro', 904578126),
(10, 'Empresa', 'Movistar', 990765411, 'lima lima', 341489389);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_detalleventa`
--

CREATE TABLE `tbl_detalleventa` (
  `idComprobante` int(100) NOT NULL,
  `fecha` varchar(20) NOT NULL,
  `idTrabajador` varchar(50) NOT NULL,
  `tipoComprobante` varchar(50) NOT NULL,
  `idCliente` varchar(50) NOT NULL,
  `precioTotal` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_detalleventa`
--

INSERT INTO `tbl_detalleventa` (`idComprobante`, `fecha`, `idTrabajador`, `tipoComprobante`, `idCliente`, `precioTotal`) VALUES
(3, '24/06/2023 18:45:00', '3 Matio', 'BOLETA', '2 Marko Villaizan', 16.5),
(4, '24/06/2023 18:57:50', '2 Mia', 'BOLETA', '2 Marko Villaizan', 6.5),
(5, '24/06/2023 19:00:55', '3 Matio', 'BOLETA', '5 Luis Figo', 12.5),
(6, '24/06/2023 23:11:50', '2 Mia', 'BOLETA', '8 Tambo', 7),
(7, '25/06/2023 01:38:43', '3 Matio', 'BOLETA', '5 Luis Figo', 15),
(8, '25/06/2023 01:42:25', '2 Mia', 'BOLETA', '8 Tambo', 37.5),
(9, '25/06/2023 01:47:30', '2 Mia', 'BOLETA', '4 jude Bellingham', 5.5),
(10, '25/06/2023 01:50:03', '4 Juan', 'BOLETA', '5 Luis Figo', 3),
(11, '25/06/2023 02:04:20', '1 Marko', 'BOLETA', '1 Luis Untiveros', 2.5),
(12, '25/06/2023 02:05:49', '3 Matio', 'BOLETA', '5 Luis Figo', 4),
(13, '25/06/2023 02:25:54', '3 Matio', 'FACTURA', '8 Tambo', 5.5),
(14, '25/06/2023 02:31:43', '2 Mia', 'FACTURA', '8 Tambo', 14),
(15, '25/06/2023 02:34:56', '4 Juan', 'FACTURA', '8 Tambo', 3),
(22, '25/06/2023 03:54:10', '1 Marko', 'FACTURA', '2 Marko Villaizan', 5),
(23, '25/06/2023 03:55:07', '2 Mia', 'FACTURA', '4 jude Bellingham', 3),
(24, '25/06/2023 04:36:31', '8 Eduardo', 'FACTURA', '4 jude Bellingham', 7.5),
(25, '25/06/2023 21:41:15', '7 Jose', 'FACTURA', '2 Marko Villaizan', 10),
(26, '25/06/2023 21:41:43', '8 Eduardo', 'FACTURA', '4 jude Bellingham', 2.5),
(27, '25/06/2023 21:43:25', '7 Jose', 'FACTURA', '1 Luis Untiveros', 14.5),
(28, '25/06/2023 21:44:44', '7 Jose', 'BOLETA', '9 claro', 2.5),
(29, '25/06/2023 21:44:56', '7 Jose', 'BOLETA', '4 jude Bellingham', 4),
(30, '25/06/2023 21:45:08', '7 Jose', 'BOLETA', '8 Tambo', 5.5),
(31, '25/06/2023 21:49:20', '7 Jose', 'FACTURA', '2 Marko Villaizan', 1.5),
(32, '25/06/2023 22:07:53', '7 Jose', 'FACTURA', '2 Marko Villaizan', 1.5),
(33, '25/06/2023 22:08:02', '7 Jose', 'FACTURA', '10 Movistar', 3),
(34, '25/06/2023 22:09:17', '8 Eduardo', 'FACTURA', '4 jude Bellingham', 1.5),
(35, '25/06/2023 22:09:30', '7 Jose', 'FACTURA', '9 claro', 4),
(36, '25/06/2023 22:10:15', '7 Jose', 'BOLETA', '2 Marko Villaizan', 1.5),
(37, '25/06/2023 22:10:23', '7 Jose', 'BOLETA', '8 Tambo', 4),
(38, '25/06/2023 22:12:06', '7 Jose', 'BOLETA', '5 Luis Figo', 1.5),
(39, '25/06/2023 22:12:13', '7 Jose', 'BOLETA', '8 Tambo', 4),
(40, '25/06/2023 22:14:55', '7 Jose', 'BOLETA', '1 Luis Untiveros', 1.5),
(41, '25/06/2023 22:15:05', '8 Eduardo', 'BOLETA', '8 Tambo', 4),
(42, '25/06/2023 22:16:04', '7 Jose', 'BOLETA', '2 Marko Villaizan', 1.5),
(43, '25/06/2023 22:16:13', '7 Jose', 'BOLETA', '9 claro', 3),
(44, '25/06/2023 22:58:31', '7 Jose', 'FACTURA', '2 Marko Villaizan', 3),
(45, '30/06/2023 01:09:22', '8 Eduardo', 'BOLETA', '4 jude Bellingham', 15.5),
(46, '30/06/2023 01:17:24', '8 Eduardo', 'BOLETA', '2 Marko Villaizan', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_productos`
--

CREATE TABLE `tbl_productos` (
  `idProductos` int(11) NOT NULL,
  `nombreP` varchar(50) NOT NULL,
  `codigoP` int(11) NOT NULL,
  `precioP` float NOT NULL,
  `cantidadP` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_productos`
--

INSERT INTO `tbl_productos` (`idProductos`, `nombreP`, `codigoP`, `precioP`, `cantidadP`) VALUES
(1, 'Frugos del Valle Fruit Punch 500ml', 1775018200, 1.5, 10),
(2, 'Oreo original 108g', 1766222016, 2.5, 12),
(3, 'Inka Chips Sal de Mar 33g', 1775052600, 2.5, 8),
(4, 'Coca cola 600ml', 1437284635, 3, 18),
(5, 'bombom', 170423884, 4, 100),
(18, 'Inka cola 600ml', 1028374273, 3, 10),
(19, 'Arroz Costeno 750g', 1093847293, 4.5, 20),
(20, 'Aceite Primor 1L', 1192839282, 13.5, 6),
(21, 'Papel Higienico Suave 4u', 1324256372, 4.5, 8),
(22, 'Detergente Bolivar 980gr', 1526374923, 9.9, 6),
(23, 'Azucar Rubia 1kg', 1263274827, 5.5, 10),
(24, 'Leche Gloria UHT 1L', 1263728493, 4.9, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_trabajador`
--

CREATE TABLE `tbl_trabajador` (
  `idTrabajador` int(11) NOT NULL,
  `nombreT` varchar(50) NOT NULL,
  `apellidoT` varchar(50) NOT NULL,
  `celularT` int(50) NOT NULL,
  `puesto` varchar(50) NOT NULL,
  `dni` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_trabajador`
--

INSERT INTO `tbl_trabajador` (`idTrabajador`, `nombreT`, `apellidoT`, `celularT`, `puesto`, `dni`) VALUES
(1, 'Marko', 'Villaizan', 987654321, 'Gerente', 78945612),
(2, 'Mia', 'Saavedra', 951753654, 'Gerente', 74512896),
(3, 'Matio', 'Pena', 903214568, 'Gerente', 75412036),
(4, 'Juan', 'Ramirez', 963258741, 'Administrador', 74123659),
(7, 'Jose', 'Quispe', 999800111, 'Vendedor', 78341221),
(8, 'Eduardo', 'Lopez', 990780980, 'Vendedor', 40405050);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `user` varchar(60) NOT NULL,
  `password` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `user`, `password`) VALUES
(1, 'matiolan', '73496400'),
(2, 'miasa', '1234'),
(3, 'markitu', '146915'),
(4, 'Luis', '1234');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `tbl_cliente`
--
ALTER TABLE `tbl_cliente`
  ADD PRIMARY KEY (`idCliente`);

--
-- Indices de la tabla `tbl_detalleventa`
--
ALTER TABLE `tbl_detalleventa`
  ADD PRIMARY KEY (`idComprobante`);

--
-- Indices de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  ADD PRIMARY KEY (`idProductos`);

--
-- Indices de la tabla `tbl_trabajador`
--
ALTER TABLE `tbl_trabajador`
  ADD PRIMARY KEY (`idTrabajador`);

--
-- Indices de la tabla `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `tbl_cliente`
--
ALTER TABLE `tbl_cliente`
  MODIFY `idCliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `tbl_detalleventa`
--
ALTER TABLE `tbl_detalleventa`
  MODIFY `idComprobante` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT de la tabla `tbl_productos`
--
ALTER TABLE `tbl_productos`
  MODIFY `idProductos` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `tbl_trabajador`
--
ALTER TABLE `tbl_trabajador`
  MODIFY `idTrabajador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
